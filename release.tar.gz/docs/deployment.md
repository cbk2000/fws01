# Deployment

To deploy this repository as Github Pages:

1. Access the repository on Github.
2. Open the `Settings` tab.
3. On the sidebar, under the `Code and Automation` sidebar section, click `Pages`.
4. Under the dropdown for `Source`, choose `Deploy from a branch`.
5. Choose the branch and directory you want to deploy.
6. Save the changes.
