# Branches

The branches on this repository are organized as follows:

## Master (`master`)
This branch is used as a baseline for development. It is also used as a base for deployment.

## Development (`dev`)
This branch is used for active development, testing, and proposed changes