# Tags
There are several tags to be used in this repository. The following format is used:

__v.XX.YY__

## XX
__XX__ denotes major releases

## YY
__YY__ denotes minor releases, and hotfixes 